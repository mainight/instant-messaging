package net.guikai.italker.push.frags.main;

import net.guikai.italker.common.app.PresenterFragment;
import net.guikai.italker.common.presenter.BaseContract;
import net.guikai.italker.push.R;

/**
 * Description:
 * Crete by Anding on 2019-11-04
 */
public class ActiveFragment extends PresenterFragment {
    @Override
    protected BaseContract.Presenter initPresenter() {
        return null;
    }

    @Override
    protected int getContentLayoutId() {
        return R.layout.lay_empty;
    }
}
