package net.guikai.italker.push.frags.account;

/**
 * Description: 登录注册切换
 * Crete by Anding on 2019-12-22
 */
public interface AccountTrigger {
    void triggerView();
}
